from django.apps import AppConfig


class AttendanceConfig(AppConfig):
    name = 'attendance'
